
const standardCards = "23456789XJDKA";
const deckLength = 5;

var   centralDeck   = [[],[]] ;


function shuffleCardDeck() {
    allCards = standardCards + standardCards + standardCards + standardCards;
    return allCards.split("").shuffle();
}


Players = [];
Players.push( new Player("Zoltan") );
Players.push( new Player("Albert") );

Array.prototype.last = function() {
    return this[this.length-1];
}


function clickCard(user, nthCard) {
    //decides whether you can place a certain card from your card dock to the to a specific part of the playzone
    if ( [1,12].indexOf(Math.abs( standardCards.indexOf(centralDeck[0].last()) - standardCards.indexOf(Players[user].frontCards[nthCard]) ) ) >= 0 )   {
        placeCard(user, nthCard, 0); 
    } 
    else if ( [1,12].indexOf(Math.abs( standardCards.indexOf(centralDeck[1].last()) - standardCards.indexOf(Players[user].frontCards[nthCard]) ) ) >= 0 )  {
        placeCard(user, nthCard, 1);
    }
    else return false;
}


function placeCard(user, nthCard, nthDeck) {
    Players[user].placeToCentralDeck(nthCard,nthDeck) ;
    updateGameUI();
}

function speedCall(userWin, userLose) {
    if ( centralDeck[0].last() == centralDeck[1].last() ) {
        console.log('speed! User ' , userLose, ' gets cards')
        
        Players[userLose].speedLose();
        
        Players[userLose].turnOver();
        Players[userWin ].turnOver();
        
        updateGameUI();
    }
}

function updateGameUI() {
    for ( let i = 0 ; i<$$('holder[user]>card').length; i++) {
        console.log(Math.floor(i/deckLength),i%deckLength);
        $$('holder[user]>card')[i].innerHTML = Players[Math.floor(i/deckLength)].frontCards[i%deckLength] ;
    }
    for ( let i = 0 ; i<$$('holder[central]>card').length; i++) {
        console.log(centralDeck[i])
        $$('holder[central]>card')[i].innerHTML = centralDeck[i].last();
        
        $$('holder[user]>div')[i].innerHTML = Players[i].cards.length + " cards";
    }
}

function initGame() {
    for (i=0; i<Players.length;i++) {
        Players[i].initPlayer();
    }
    updateGameUI();
}
function splash(first,second) {
    Players[first ].turnOver();
    Players[second].turnOver();
    updateGameUI();
}


function keyBoardControl(e) {
    
}

setTimeout( () => initGame() , 200) ;

document.body.onkeypress = function(event) { keyBoardControl(event); }

/*version history
//0.1.0  starting speed, creating table <13.05.13>
//0.1.1  random numbers, design added
//0.1.2  placing card (not valid) [UNITY] 

//0.2.0  placing card (valid!) <13.05.18>
//0.2.1  placing cards AB + two slots
//0.2.2  card remaining (42 alap), go less
//0.2.2B placing cards bugfix (2->>A) <13.05.19>
//0.2.3  redesign (bit)
//0.2.4  felcsapás
//0.2.6  removing double cards (hardwork)
//0.2.7  starting implementing game end [UNIT] 

//0.3.0  adding '^' endcards
//0.3.1  stresstest
//0.3.2  user B added (not implemented since 2.4)
//0.3.3  starting implementing SPEED
//0.3.4  added for both (A+B)
//0.3.5  bugfixes

//0.9.0  WORKS RESTARTED IN 2017 w/agocsago [RTS4/SOTON]
//0.9.0  completely rewriteen from grounds-up, using NXT-JS
//0.9.1  user class added
//0.9.2  functinal base click

*/